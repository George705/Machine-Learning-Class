# 2022-PH451-PH551
Repo for the 2023 course on Machine Learning at the University of Alabama.   
For details on the submission of the exercises see [here](Exercises/SubmissionDetails.md).

Following the book [Hands-on Machine Learning with Scikit-Learn, Keras and TensorFlow](https://www.oreilly.com/library/view/hands-on-machine-learning/9781492032632/) by Aurélien Géron.
![book image](https://learning.oreilly.com/library/cover/9781492032632/250w/)

The official repo for the book is [here](https://github.com/ageron/handson-ml2).
Most exercises are adapted from the books exercises.
